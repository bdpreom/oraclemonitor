create trigger ACT_VEHICLE_DTL_UPDATE_TRIGGER
  after update
  on ACTIVITY_VEHICLE_DETAIL
  for each row
  BEGIN
    insert_into_source_sync_table('ACTIVITY_VEHICLE_DETAIL', :new.activity_id, 1, SYSTIMESTAMP);
  END;
/

