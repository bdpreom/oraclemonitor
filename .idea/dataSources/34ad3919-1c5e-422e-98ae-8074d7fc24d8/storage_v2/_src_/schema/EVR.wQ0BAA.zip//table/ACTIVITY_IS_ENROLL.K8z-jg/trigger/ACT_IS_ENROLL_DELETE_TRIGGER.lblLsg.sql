create trigger ACT_IS_ENROLL_DELETE_TRIGGER
  after delete
  on ACTIVITY_IS_ENROLL
  for each row
  BEGIN
    insert_into_source_sync_table('ACTIVITY_IS_ENROLL', :old.activity_id, 2, SYSTIMESTAMP);
  END;
/

