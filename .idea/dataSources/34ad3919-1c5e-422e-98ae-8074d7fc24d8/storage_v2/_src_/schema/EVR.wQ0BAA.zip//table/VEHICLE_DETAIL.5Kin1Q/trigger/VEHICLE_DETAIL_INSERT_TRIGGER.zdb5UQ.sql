create trigger VEHICLE_DETAIL_INSERT_TRIGGER
  after insert
  on VEHICLE_DETAIL
  for each row
  BEGIN
    insert_into_source_sync_table('VEHICLE_DETAIL', :NEW.id, 0, SYSTIMESTAMP);
  END;
/

