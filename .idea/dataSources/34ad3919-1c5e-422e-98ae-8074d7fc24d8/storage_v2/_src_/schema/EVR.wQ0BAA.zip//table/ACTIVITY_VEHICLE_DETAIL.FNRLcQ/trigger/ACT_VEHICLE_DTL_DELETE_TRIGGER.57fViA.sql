create trigger ACT_VEHICLE_DTL_DELETE_TRIGGER
  after delete
  on ACTIVITY_VEHICLE_DETAIL
  for each row
  BEGIN
    insert_into_source_sync_table('ACTIVITY_VEHICLE_DETAIL', :old.activity_id, 2, SYSTIMESTAMP);
  END;
/

