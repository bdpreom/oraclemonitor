create trigger ACT_VEHICLE_DTL_INSERT_TRIGGER
  after insert
  on ACTIVITY_VEHICLE_DETAIL
  for each row
  BEGIN
    insert_into_source_sync_table('ACTIVITY_VEHICLE_DETAIL', :NEW.activity_id, 0, SYSTIMESTAMP);
  END;
/

