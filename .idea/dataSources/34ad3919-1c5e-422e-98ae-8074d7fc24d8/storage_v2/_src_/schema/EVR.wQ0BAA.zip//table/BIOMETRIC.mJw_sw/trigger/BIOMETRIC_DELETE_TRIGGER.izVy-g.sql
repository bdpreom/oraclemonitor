create trigger BIOMETRIC_DELETE_TRIGGER
  after delete
  on BIOMETRIC
  for each row
  BEGIN
    insert_into_source_sync_table('BIOMETRIC', :old.id, 2, SYSTIMESTAMP);
  END;
/

