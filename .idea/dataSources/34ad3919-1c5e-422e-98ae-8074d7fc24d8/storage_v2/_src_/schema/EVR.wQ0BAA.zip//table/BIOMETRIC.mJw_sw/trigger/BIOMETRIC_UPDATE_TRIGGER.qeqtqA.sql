create trigger BIOMETRIC_UPDATE_TRIGGER
  after update
  on BIOMETRIC
  for each row
  BEGIN
    insert_into_source_sync_table('BIOMETRIC', :new.id, 1, SYSTIMESTAMP);
  END;
/

