create materialized view BRTA_IS_TRANSACTION_MV
refresh fast on demand
  as
    SELECT reg_no, chassis_no,transaction_no, count(*) request_count, max(request_time) request_time
    FROM BRTA_IS_TRANSACTION
    WHERE response_code is null OR response_code > 0
    GROUP BY reg_no, chassis_no, transaction_no
/

