create trigger VEHICLE_DETAIL_UPDATE_TRIGGER
  after update
  on VEHICLE_DETAIL
  for each row
  BEGIN
    insert_into_source_sync_table('VEHICLE_DETAIL', :new.id, 1, SYSTIMESTAMP);
  END;
/

