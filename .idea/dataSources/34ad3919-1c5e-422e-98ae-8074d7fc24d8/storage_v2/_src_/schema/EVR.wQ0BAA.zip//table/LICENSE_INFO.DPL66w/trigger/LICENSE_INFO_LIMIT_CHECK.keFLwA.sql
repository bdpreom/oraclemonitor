create trigger LICENSE_INFO_LIMIT_CHECK
  before insert
  on LICENSE_INFO
  for each row
  DECLARE
     max_limit NUMBER;
   BEGIN
     SELECT (:new.key_limit - max(KEY_LIMIT)) INTO max_limit FROM license_info;
     IF max_limit <= 0 THEN
       RAISE_APPLICATION_ERROR(-20000, 'please insert larger value');
     END IF;
   END;





/

