create PROCEDURE insert_into_source_sync_table (tableName VARCHAR2, primaryKey VARCHAR2, action Number, insertTime TIMESTAMP) AS
  BEGIN
    INSERT INTO SOURCE_SYNC_TABLE (ID, TABLE_NAME, PRIMARY_KEY, ACTION, INSERT_TIME) VALUES(source_sync_table_seq.nextval, tableName, primaryKey, action, insertTime);
  END;
/

