create trigger BIOMETRIC_INSERT_TRIGGER
  after insert
  on BIOMETRIC
  for each row
  BEGIN
    insert_into_source_sync_table('BIOMETRIC', :NEW.id, 0, SYSTIMESTAMP);
  END;
/

