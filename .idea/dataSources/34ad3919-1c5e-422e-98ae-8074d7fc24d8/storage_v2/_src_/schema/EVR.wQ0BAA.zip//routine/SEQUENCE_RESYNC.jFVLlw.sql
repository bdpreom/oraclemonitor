create PROCEDURE sequence_resync (seq_name VARCHAR2, table_name VARCHAR2, col_name VARCHAR2) 
IS
  curr_seq NUMBER;
  new_seq  NUMBER;
  max_id   NUMBER;
  diff     NUMBER;
BEGIN
  execute immediate 'SELECT '|| seq_name ||'.nextval FROM DUAL' INTO curr_seq;
  execute immediate 'SELECT max('||col_name||') FROM '||table_name INTO max_id;
  diff := max_id - curr_seq;
  IF diff > 0 THEN
    execute immediate 'ALTER SEQUENCE  '|| seq_name ||' INCREMENT BY ' || to_char(diff);
    execute immediate 'SELECT '|| seq_name ||'.nextval FROM dual' into new_seq;
    DBMS_OUTPUT.put_line(table_name||': MAX='||max_id ||' CURR='|| curr_seq||' NEW='||new_seq);
    execute immediate 'alter sequence  '|| seq_name ||' increment by 1';
  ELSE
    DBMS_OUTPUT.put_line('ACTIVITY_CARD_MACHINE_CA_SEQ :: MAX='||max_id ||' CURR='|| curr_seq);
  END IF;
END;
/

