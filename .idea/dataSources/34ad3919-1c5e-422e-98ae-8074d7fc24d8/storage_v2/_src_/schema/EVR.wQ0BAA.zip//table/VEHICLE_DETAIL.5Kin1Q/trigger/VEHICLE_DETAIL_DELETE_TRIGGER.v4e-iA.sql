create trigger VEHICLE_DETAIL_DELETE_TRIGGER
  after delete
  on VEHICLE_DETAIL
  for each row
  BEGIN
    insert_into_source_sync_table('VEHICLE_DETAIL', :old.id, 2, SYSTIMESTAMP);
  END;
/

