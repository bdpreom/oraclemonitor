create trigger ACT_IS_ENROLL_UPDATE_TRIGGER
  after update
  on ACTIVITY_IS_ENROLL
  for each row
  BEGIN
    insert_into_source_sync_table('ACTIVITY_IS_ENROLL', :new.activity_id, 1, SYSTIMESTAMP);
  END;
/

