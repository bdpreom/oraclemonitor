create trigger IS_ENROLL_UPDATE_TRIGGER
  after update
  on IS_ENROLL
  for each row
  BEGIN
    insert_into_source_sync_table('IS_ENROLL', :new.id, 1, SYSTIMESTAMP);
  END;
/

