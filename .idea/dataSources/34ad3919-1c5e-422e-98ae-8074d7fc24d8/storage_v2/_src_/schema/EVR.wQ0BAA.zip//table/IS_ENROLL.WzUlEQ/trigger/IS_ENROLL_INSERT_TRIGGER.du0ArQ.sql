create trigger IS_ENROLL_INSERT_TRIGGER
  after insert
  on IS_ENROLL
  for each row
  BEGIN
    insert_into_source_sync_table('IS_ENROLL', :NEW.id, 0, SYSTIMESTAMP);
  END;
/

