create trigger IS_ENROLL_DELETE_TRIGGER
  after delete
  on IS_ENROLL
  for each row
  BEGIN
    insert_into_source_sync_table('IS_ENROLL', :old.id, 2, SYSTIMESTAMP);
  END;
/

