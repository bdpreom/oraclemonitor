create trigger ACT_IS_ENROLL_INSERT_TRIGGER
  after insert
  on ACTIVITY_IS_ENROLL
  for each row
  BEGIN
    insert_into_source_sync_table('ACTIVITY_IS_ENROLL', :NEW.activity_id, 0, SYSTIMESTAMP);
  END;
/

