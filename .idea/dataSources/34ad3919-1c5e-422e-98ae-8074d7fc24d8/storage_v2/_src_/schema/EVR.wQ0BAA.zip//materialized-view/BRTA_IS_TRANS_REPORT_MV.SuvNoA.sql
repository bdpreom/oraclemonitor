create materialized view BRTA_IS_TRANS_REPORT_MV
refresh fast on demand
  as
    select
		extract(year from request_time) request_year,
		extract(month from request_time) request_month,
		extract(day from request_time) request_day,
		extract(hour from request_time) request_hour,
		response_code,
		rule_id,
		count(*) request_count
    from brta_is_transaction
    group by
		extract(year from request_time),
		extract(month from request_time),
		extract(day from request_time),
		extract(hour from request_time),
		response_code,
		rule_id
/

