create PROCEDURE FIX_EPC_INCONSISTENCY IS
BEGIN
    FOR r1 IN (select i.id, p.epc, p.tag_id
    from personalize p
          join is_enroll i on (i.id = p.enroll_id)
          where i.epc <> p.epc and p.status = 8) LOOP
    update is_enroll set epc=r1.epc, tag_id=r1.tag_id where id = r1.id;
    END LOOP;
END Fix_Epc_Inconsistency;
/

