create trigger INSERT_TIME_COUNTRIES
  before insert or update
  on TEST_TABLE
  for each row
  BEGIN

   IF :OLD.TIME IS NULL OR :OLD.TIME < SYSTIMESTAMP THEN
     :NEW.TIME := SYSTIMESTAMP;
   ELSE
     :NEW.TIME := :OLD.TIME + 1 / 86400;
   END IF;
END;
/

