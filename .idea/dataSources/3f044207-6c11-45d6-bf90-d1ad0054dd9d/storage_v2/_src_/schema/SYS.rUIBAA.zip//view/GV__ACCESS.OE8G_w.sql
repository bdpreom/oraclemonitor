create view GV_$ACCESS as
  select "INST_ID","SID","OWNER","OBJECT","TYPE","CON_ID" from gv$access
/

