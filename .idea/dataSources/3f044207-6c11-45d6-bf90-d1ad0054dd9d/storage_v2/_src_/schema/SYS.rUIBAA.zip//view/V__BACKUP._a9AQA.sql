create view V_$BACKUP as
  select "FILE#","STATUS","CHANGE#","TIME","CON_ID" from v$backup
/

