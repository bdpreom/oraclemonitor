create view GV_$LATCHNAME as
  select "INST_ID","LATCH#","NAME","DISPLAY_NAME","HASH","TYPE","CON_ID" from gv$latchname
/

