create view V_$DETACHED_SESSION as
  select "INDX","PG_NAME","SID","SERIAL#","PID","CON_ID" from v$detached_session
/

