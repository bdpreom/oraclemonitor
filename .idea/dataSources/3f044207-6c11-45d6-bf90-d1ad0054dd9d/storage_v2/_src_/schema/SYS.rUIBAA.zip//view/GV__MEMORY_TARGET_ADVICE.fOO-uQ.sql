create view GV_$MEMORY_TARGET_ADVICE as
  select "INST_ID","MEMORY_SIZE","MEMORY_SIZE_FACTOR","ESTD_DB_TIME","ESTD_DB_TIME_FACTOR","VERSION","CON_ID" from gv$memory_target_advice
/

