create view V_$SYSMETRIC_HISTORY as
  select "BEGIN_TIME","END_TIME","INTSIZE_CSEC","GROUP_ID","METRIC_ID","METRIC_NAME","VALUE","METRIC_UNIT","CON_ID" from v$sysmetric_history
/

