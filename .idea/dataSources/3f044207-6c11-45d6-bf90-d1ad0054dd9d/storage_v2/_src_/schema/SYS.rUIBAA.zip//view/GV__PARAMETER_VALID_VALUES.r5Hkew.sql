create view GV_$PARAMETER_VALID_VALUES as
  select "INST_ID","NUM","NAME","ORDINAL","VALUE","ISDEFAULT","CON_ID" from gv$parameter_valid_values
/

