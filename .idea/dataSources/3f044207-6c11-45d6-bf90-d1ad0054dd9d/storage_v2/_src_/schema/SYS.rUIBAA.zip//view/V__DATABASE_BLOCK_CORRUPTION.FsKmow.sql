create view V_$DATABASE_BLOCK_CORRUPTION as
  select "FILE#","BLOCK#","BLOCKS","CORRUPTION_CHANGE#","CORRUPTION_TYPE","CON_ID" from
   v$database_block_corruption
/

