create view V_$ENABLEDPRIVS as
  select "PRIV_NUMBER","SCOPE","CON_ID" from v$enabledprivs
/

