create view GV_$SESSTAT as
  select "INST_ID","SID","STATISTIC#","VALUE","CON_ID" from gv$sesstat
/

