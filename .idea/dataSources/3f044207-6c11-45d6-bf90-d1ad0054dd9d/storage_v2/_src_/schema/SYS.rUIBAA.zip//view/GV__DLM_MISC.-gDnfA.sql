create view GV_$DLM_MISC as
  select "INST_ID","STATISTIC#","NAME","VALUE","CON_ID" from gv$dlm_misc
/

