create view V_$CON_EVENT_HISTOGRAM_MICRO as
  select "EVENT#","EVENT","WAIT_TIME_FORMAT","WAIT_TIME_MICRO","WAIT_COUNT","LAST_UPDATE_TIME","CON_ID" from v$con_event_histogram_micro
/

