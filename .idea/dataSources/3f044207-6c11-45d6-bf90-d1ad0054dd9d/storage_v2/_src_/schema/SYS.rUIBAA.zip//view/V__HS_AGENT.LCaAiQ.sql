create view V_$HS_AGENT as
  select "AGENT_ID","MACHINE","PROCESS","PROGRAM","OSUSER","STARTTIME","AGENT_TYPE","FDS_CLASS_ID","FDS_INST_ID","CON_ID" from v$hs_agent
/

