create view GV_$PX_PROCESS_TRACE as
  select "INST_ID","TIME_STAMP","PID","SPID","SLVID","PNAME","SID","QC_INST_ID","QCSID","SERVER_SET","SERVER#","COMP","FILENAME","LINE","FUNC","TRACE","CON_ID" from gv$px_process_trace
/

