create view V_$SHARED_SERVER as
  select "NAME","PADDR","STATUS","MESSAGES","BYTES","BREAKS","CIRCUIT","IDLE","BUSY","IN_NET","OUT_NET","REQUESTS","CON_ID" from v$shared_server
/

