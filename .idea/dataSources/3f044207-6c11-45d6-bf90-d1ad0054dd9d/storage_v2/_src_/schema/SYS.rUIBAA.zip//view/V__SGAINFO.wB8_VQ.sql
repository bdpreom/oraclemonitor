create view V_$SGAINFO as
  select "NAME","BYTES","RESIZEABLE","CON_ID" from v$sgainfo
/

