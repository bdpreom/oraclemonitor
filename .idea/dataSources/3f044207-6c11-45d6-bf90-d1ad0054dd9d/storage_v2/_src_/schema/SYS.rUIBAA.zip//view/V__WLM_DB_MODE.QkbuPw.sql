create view V_$WLM_DB_MODE as
  select "PDB","SERVICE_NAME","PC_NAME_HASH","PC_NAME","PC_RANK","MEASURE_ONLY","PC_POV","CON_ID" from v$wlm_db_mode
/

