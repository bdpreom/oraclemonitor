create view V_$PASSWORDFILE_INFO as
  select "FILE_NAME","FORMAT","IS_ASM","CON_ID" from v$passwordfile_info
/

