create view V_$OBJECT_PRIVILEGE as
  select "OBJECT_TYPE_NAME","OBJECT_TYPE_ID","PRIVILEGE_ID","PRIVILEGE_NAME","CON_ID" from v$object_privilege
/

