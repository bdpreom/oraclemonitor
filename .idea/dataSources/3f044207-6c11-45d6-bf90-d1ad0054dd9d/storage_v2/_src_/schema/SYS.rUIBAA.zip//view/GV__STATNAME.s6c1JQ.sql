create view GV_$STATNAME as
  select "INST_ID","STATISTIC#","NAME","CLASS","STAT_ID","DISPLAY_NAME","CON_ID" from gv$statname
/

