create view V_$MAP_FILE_EXTENT as
  select "FILE_MAP_IDX","EXT_NUM","EXT_ELEM_OFF","EXT_SIZE","EXT_FILE_OFF","EXT_TYPE","ELEM_IDX","CON_ID" from v$map_file_extent
/

