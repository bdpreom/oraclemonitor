create view V_$MAX_ACTIVE_SESS_TARGET_MTH as
  select "NAME","CON_ID" from v$max_active_sess_target_mth
/

