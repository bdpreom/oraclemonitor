create view V_$RECOVER_FILE as
  select "FILE#","ONLINE","ONLINE_STATUS","ERROR","CHANGE#","TIME","CON_ID" from v$recover_file
/

