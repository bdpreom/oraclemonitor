create view V_$ARCHIVE_GAP as
  select "THREAD#","LOW_SEQUENCE#","HIGH_SEQUENCE#","CON_ID" from v$archive_gap
/

