create view V_$SEGSTAT as
  select "TS#","OBJ#","DATAOBJ#","STATISTIC_NAME","STATISTIC#","VALUE","CON_ID" from v$segstat
/

