create view V_$TIMEZONE_FILE as
  select "FILENAME","VERSION","CON_ID" from v$timezone_file
/

