create view V_$FAST_START_SERVERS as
  select "STATE","UNDOBLOCKSDONE","PID","XID","CON_ID" from v$fast_start_servers
/

