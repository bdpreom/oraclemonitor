create view V_$BT_SCAN_CACHE as
  select "BT_CACHE_ALLOC","BT_CACHE_TARGET","OBJECT_COUNT","MEMORY_BUF_ALLOC","MIN_CACHED_TEMP","CON_ID" from v$bt_scan_cache
/

