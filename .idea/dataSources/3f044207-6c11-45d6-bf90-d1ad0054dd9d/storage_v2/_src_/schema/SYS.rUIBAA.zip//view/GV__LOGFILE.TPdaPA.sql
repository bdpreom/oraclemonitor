create view GV_$LOGFILE as
  select "INST_ID","GROUP#","STATUS","TYPE","MEMBER","IS_RECOVERY_DEST_FILE","CON_ID" from gv$logfile
/

