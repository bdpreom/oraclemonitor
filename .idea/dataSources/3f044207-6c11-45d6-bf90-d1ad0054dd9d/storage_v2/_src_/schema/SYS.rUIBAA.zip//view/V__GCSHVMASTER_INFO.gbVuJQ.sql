create view V_$GCSHVMASTER_INFO as
  select "HV_ID","CURRENT_MASTER","PREVIOUS_MASTER","REMASTER_CNT","CON_ID" from v$gcshvmaster_info
/

