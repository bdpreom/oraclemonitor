create view V_$PQ_SESSTAT as
  select "STATISTIC","LAST_QUERY","SESSION_TOTAL","CON_ID" from v$pq_sesstat
/

