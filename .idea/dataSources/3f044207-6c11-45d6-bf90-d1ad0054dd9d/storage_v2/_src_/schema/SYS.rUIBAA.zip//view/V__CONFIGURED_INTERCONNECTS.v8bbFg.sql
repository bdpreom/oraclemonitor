create view V_$CONFIGURED_INTERCONNECTS as
  select "NAME","IP_ADDRESS","IS_PUBLIC","SOURCE","CON_ID" from v$configured_interconnects
/

