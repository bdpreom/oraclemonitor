create view GV_$ENABLEDPRIVS as
  select "INST_ID","PRIV_NUMBER","SCOPE","CON_ID" from gv$enabledprivs
/

