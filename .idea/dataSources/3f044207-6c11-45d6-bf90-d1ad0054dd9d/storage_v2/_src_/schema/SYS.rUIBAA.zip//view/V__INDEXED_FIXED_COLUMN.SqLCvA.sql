create view V_$INDEXED_FIXED_COLUMN as
  select "TABLE_NAME","INDEX_NUMBER","COLUMN_NAME","COLUMN_POSITION","CON_ID" from v$indexed_fixed_column
/

