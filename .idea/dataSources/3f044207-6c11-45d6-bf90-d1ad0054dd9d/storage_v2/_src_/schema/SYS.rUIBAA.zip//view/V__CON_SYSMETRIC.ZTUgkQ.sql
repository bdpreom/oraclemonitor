create view V_$CON_SYSMETRIC as
  select "BEGIN_TIME","END_TIME","INTSIZE_CSEC","GROUP_ID","METRIC_ID","METRIC_NAME","VALUE","METRIC_UNIT","CON_ID" from v$con_sysmetric
/

