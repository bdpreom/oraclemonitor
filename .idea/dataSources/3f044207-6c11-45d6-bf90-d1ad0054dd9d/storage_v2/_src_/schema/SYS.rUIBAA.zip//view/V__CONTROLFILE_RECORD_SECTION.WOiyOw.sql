create view V_$CONTROLFILE_RECORD_SECTION as
  select "TYPE","RECORD_SIZE","RECORDS_TOTAL","RECORDS_USED","FIRST_INDEX","LAST_INDEX","LAST_RECID","CON_ID" from v$controlfile_record_section
/

