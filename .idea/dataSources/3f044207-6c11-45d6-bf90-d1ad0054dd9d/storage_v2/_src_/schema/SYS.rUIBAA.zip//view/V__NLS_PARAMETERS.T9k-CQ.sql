create view V_$NLS_PARAMETERS as
  select "PARAMETER","VALUE","CON_ID" from v$nls_parameters
/

