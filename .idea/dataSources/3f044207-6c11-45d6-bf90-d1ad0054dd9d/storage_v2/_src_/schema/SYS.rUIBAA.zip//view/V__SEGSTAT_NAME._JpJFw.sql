create view V_$SEGSTAT_NAME as
  select "STATISTIC#","NAME","SAMPLED","CON_ID" from v$segstat_name
/

