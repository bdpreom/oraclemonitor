create view V_$FLASHFILESTAT as
  select "FLASHFILE#","NAME","BYTES","ENABLED","SINGLEBLKRDS","SINGLEBLKRDTIM_MICRO","CON_ID" from v$flashfilestat
/

