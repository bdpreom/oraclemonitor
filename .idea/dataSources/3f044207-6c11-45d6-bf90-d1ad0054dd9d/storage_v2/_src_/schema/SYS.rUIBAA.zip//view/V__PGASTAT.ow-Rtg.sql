create view V_$PGASTAT as
  select "NAME","VALUE","UNIT","CON_ID" from v$pgastat
/

