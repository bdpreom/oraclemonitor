create view V_$TIMER as
  select "HSECS","CON_ID" from v$timer
/

