create view GV_$DLM_CONVERT_LOCAL as
  select "INST_ID","CONVERT_TYPE","AVERAGE_CONVERT_TIME","CONVERT_COUNT","CON_ID" from gv$dlm_convert_local
/

