create view V_$BLOCKING_QUIESCE as
  select "SID","CON_ID" from v$blocking_quiesce
/

