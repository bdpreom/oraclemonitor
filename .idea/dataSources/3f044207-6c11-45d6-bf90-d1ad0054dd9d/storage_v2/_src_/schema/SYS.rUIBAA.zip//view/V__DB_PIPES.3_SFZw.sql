create view V_$DB_PIPES as
  select "OWNERID","NAME","TYPE","PIPE_SIZE","CON_ID","CON_NAME" from v$db_pipes
/

