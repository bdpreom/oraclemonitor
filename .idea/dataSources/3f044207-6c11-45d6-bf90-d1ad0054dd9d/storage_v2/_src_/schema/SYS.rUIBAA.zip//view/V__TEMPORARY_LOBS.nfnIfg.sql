create view V_$TEMPORARY_LOBS as
  select "SID","CACHE_LOBS","NOCACHE_LOBS","ABSTRACT_LOBS","CON_ID" from v$temporary_lobs
/

