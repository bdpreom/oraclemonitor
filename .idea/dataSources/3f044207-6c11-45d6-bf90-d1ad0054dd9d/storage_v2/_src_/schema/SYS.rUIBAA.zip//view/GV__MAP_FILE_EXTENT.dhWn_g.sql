create view GV_$MAP_FILE_EXTENT as
  select "INST_ID","FILE_MAP_IDX","EXT_NUM","EXT_ELEM_OFF","EXT_SIZE","EXT_FILE_OFF","EXT_TYPE","ELEM_IDX","CON_ID" from gv$map_file_extent
/

