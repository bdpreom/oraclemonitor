create view V_$SPPARAMETER as
  select "FAMILY","SID","NAME","TYPE","VALUE","DISPLAY_VALUE","ISSPECIFIED","ORDINAL","UPDATE_COMMENT","CON_ID" from v$spparameter
/

