create view V_$DATAGUARD_STATS as
  select "SOURCE_DBID","SOURCE_DB_UNIQUE_NAME","NAME","VALUE","UNIT","TIME_COMPUTED","DATUM_TIME","CON_ID" from v$dataguard_stats
/

