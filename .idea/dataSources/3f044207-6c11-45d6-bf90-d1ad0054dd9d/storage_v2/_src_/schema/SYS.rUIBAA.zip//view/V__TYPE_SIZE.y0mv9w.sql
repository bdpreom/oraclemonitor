create view V_$TYPE_SIZE as
  select "COMPONENT","TYPE","DESCRIPTION","TYPE_SIZE","CON_ID" from v$type_size
/

