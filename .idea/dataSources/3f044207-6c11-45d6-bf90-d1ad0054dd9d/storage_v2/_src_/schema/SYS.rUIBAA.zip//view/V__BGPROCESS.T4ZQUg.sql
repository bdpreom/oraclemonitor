create view V_$BGPROCESS as
  select "PADDR","PSERIAL#","NAME","DESCRIPTION","ERROR","TYPE","CON_ID" from v$bgprocess
/

