create view V_$LATCHNAME as
  select "LATCH#","NAME","DISPLAY_NAME","HASH","TYPE","CON_ID" from v$latchname
/

