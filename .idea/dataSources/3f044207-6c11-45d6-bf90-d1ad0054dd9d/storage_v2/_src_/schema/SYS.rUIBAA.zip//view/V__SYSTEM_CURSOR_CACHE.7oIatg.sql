create view V_$SYSTEM_CURSOR_CACHE as
  select "OPENS","HITS","HIT_RATIO","CON_ID" from v$system_cursor_cache
/

