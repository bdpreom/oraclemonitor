create view V_$LOGFILE as
  select "GROUP#","STATUS","TYPE","MEMBER","IS_RECOVERY_DEST_FILE","CON_ID" from v$logfile
/

