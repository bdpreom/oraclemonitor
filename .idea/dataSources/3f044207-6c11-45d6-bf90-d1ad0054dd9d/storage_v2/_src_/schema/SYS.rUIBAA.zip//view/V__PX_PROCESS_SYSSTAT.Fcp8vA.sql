create view V_$PX_PROCESS_SYSSTAT as
  select "STATISTIC","VALUE","CON_ID" from v$px_process_sysstat
/

