create view V_$HVMASTER_INFO as
  select "HV_ID","CURRENT_MASTER","PREVIOUS_MASTER","REMASTER_CNT","CON_ID" from v$hvmaster_info
/

